const SubadminDashboard = () => {
    return (
      <div className="p-4 text-xl font-semibold">
        Welcome Subadmin 👋 — You have logged in successfully.
      </div>
    );
  };
  
  export default SubadminDashboard;
  