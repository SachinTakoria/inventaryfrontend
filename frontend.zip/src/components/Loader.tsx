 

const Loader = () => {
  return (
    <div>loading....</div>
  )
}

export default Loader